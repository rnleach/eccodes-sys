void fun2(void);
int main(void) {
 fun2();
 return 0;
}
